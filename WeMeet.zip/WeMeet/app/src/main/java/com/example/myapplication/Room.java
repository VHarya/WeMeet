package com.example.myapplication;

public class Room {
    public String name;
    public boolean isUsed;

    public String getName() {
        return name;
    }

    public boolean getUsed() {
        return isUsed;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsed(boolean used) {
        isUsed = used;
    }
}
