package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RoomInfo extends AppCompatActivity {

    private TextView RoomName;
    private ListView scheduleList;
    private Button bookBt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_info);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Room Info");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        String name = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        bookBt = findViewById(R.id.bookRoomBt);
        RoomName = findViewById(R.id.RoomName);
        scheduleList = findViewById(R.id.bookingList);

        RoomName.setText(name);

        ArrayList<String> timeUsed = new ArrayList<>();
        timeUsed.add("10.00 - 11.00 \n\t Lorem ipsun");
        timeUsed.add("8.00 - 9.00 \n\t Lorem ipsun");
        timeUsed.add("13.00 - 14.00 \n\t Lorem ipsun");

        ArrayAdapter<String> timeUsedAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, timeUsed);
        scheduleList.setAdapter(timeUsedAdapter);

        bookBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBookActivity();
            }
        });
    }

    void openBookActivity() {
        Intent intent = new Intent(RoomInfo.this, RoomBooking.class);
        startActivity(intent);
    }
}