package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.myapplication.EXTRA_TEXT";

    private ListView roomList;
    private ListView meetingList;

    private ArrayList<String> rooms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        roomList = findViewById(R.id.roomList);
        meetingList = findViewById(R.id.meetingList);

        rooms.add("Room 1");
        rooms.add("Room 2");
        rooms.add("Room 3");
        rooms.add("Room 4");
        rooms.add("Room 5");
        rooms.add("Room 6");
        rooms.add("Room 7");

        ArrayAdapter<String> roomAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rooms);
        roomList.setAdapter(roomAdapter);
        roomList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String roomName = rooms.get(position);

                Intent intent = new Intent(MainActivity.this, RoomInfo.class);
                intent.putExtra(EXTRA_TEXT, roomName);
                startActivity(intent);
            }
        });

        ArrayList<String> meetings = new ArrayList<>();
        meetings.add("27/4/2021 \n10.00 - 11.00 \n\tLorem ipsun");
        meetings.add("28/4/2021 \n12.00 - 14.00 \n\tLorem ipsun");

        ArrayAdapter<String> meetingsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, meetings);
        meetingList.setAdapter(meetingsAdapter);
    }
}

